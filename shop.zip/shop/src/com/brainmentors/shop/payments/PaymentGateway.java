package com.brainmentors.shop.payments;

public class PaymentGateway {
	
	public String[] getPaymentGateway() {
		return new String[]{"MasterCard","PayTM","NetBanking"};
	}

}
