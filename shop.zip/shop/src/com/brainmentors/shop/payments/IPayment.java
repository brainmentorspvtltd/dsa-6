package com.brainmentors.shop.payments;

public interface IPayment {
	
	public boolean pay(double amount) ;

}
