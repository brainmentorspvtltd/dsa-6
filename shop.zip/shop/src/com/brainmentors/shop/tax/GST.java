package com.brainmentors.shop.tax;

public class GST {
	
	public int getTax(){
		return 18;
	}

}
