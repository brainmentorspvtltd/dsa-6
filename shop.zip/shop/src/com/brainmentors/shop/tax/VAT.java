package com.brainmentors.shop.tax;

public class VAT {

}
